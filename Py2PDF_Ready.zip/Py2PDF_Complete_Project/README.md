# Py2PDF - Local Android Python to PDF Generator

Py2PDF is a complete offline-first Android application designed to execute Python code locally and generate PDF documents with full Bangla Unicode & complex script support.

## Features
- **Local Execution**: Uses Chaquopy for on-device Python interpretation.
- **Bangla Font Renderer**: Embedded Noto Sans Bengali font management.
- **Jetpack Compose UI**: Modern Android user interface.
- **Automated GitHub APK Build**: CI/CD pipeline included.

package com.py2pdf

import androidx.compose.runtime.*
import com.py2pdf.presentation.editor.EditorViewModel
import com.py2pdf.presentation.editor.PythonCodeEditor
import com.py2pdf.presentation.preview.PdfPreviewScreen
import com.py2pdf.presentation.theme.Py2PDFTheme

@Composable
fun Py2PDFApp(viewModel: EditorViewModel = EditorViewModel()) {
    val project by viewModel.project.collectAsState()
    var currentScreen by remember { mutableStateOf("editor") }
    var generatedPdfPath by remember { mutableStateOf<String?>(null) }

    Py2PDFTheme {
        if (currentScreen == "editor") {
            PythonCodeEditor(
                code = project.code,
                onCodeChange = { viewModel.updateCode(it) },
                onRunClick = {
                    viewModel.runAnalysis()
                    generatedPdfPath = "sample_output.pdf"
                    currentScreen = "preview"
                }
            )
        } else {
            PdfPreviewScreen(
                pdfPath = generatedPdfPath,
                onShareClick = { /* Share logic */ },
                onBackClick = { currentScreen = "editor" }
            )
        }
    }
}

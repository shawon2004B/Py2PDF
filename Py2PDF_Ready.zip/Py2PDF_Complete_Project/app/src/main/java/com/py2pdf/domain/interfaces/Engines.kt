package com.py2pdf.domain.interfaces

import com.py2pdf.domain.models.ExecutionResult
import com.py2pdf.domain.models.PdfSettings

interface PythonExecutionEngine {
    suspend fun executeScript(code: String, outputDir: String): ExecutionResult
}

interface PdfGenerationEngine {
    suspend fun createPdf(text: String, outputPath: String, settings: PdfSettings): Boolean
}

package com.py2pdf.domain.models

data class PythonProject(
    val id: String = "1",
    val name: String = "Untitled Script",
    val code: String = "",
    val settings: PdfSettings = PdfSettings()
)

data class PdfSettings(
    val pageSize: String = "A4",
    val orientation: String = "Portrait",
    val selectedFont: String = "Noto Sans Bengali",
    val enableBanglaSupport: Boolean = true
)

data class AnalysisResult(
    val isValid: Boolean,
    val diagnostics: List<Diagnostic> = emptyList(),
    val hasBanglaText: Boolean = false
)

data class Diagnostic(
    val line: Int,
    val message: String,
    val severity: Severity
)

enum class Severity { WARNING, ERROR, INFO }

data class FontInfo(
    val name: String,
    val fileName: String,
    val isBanglaSupported: Boolean,
    val isEmbedded: Boolean = true
)

data class ExecutionResult(
    val isSuccess: Boolean,
    val outputText: String,
    val pdfPath: String? = null,
    val errorMessage: String? = null
)

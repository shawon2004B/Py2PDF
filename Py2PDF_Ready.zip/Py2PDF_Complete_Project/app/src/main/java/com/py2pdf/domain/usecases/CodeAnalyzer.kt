package com.py2pdf.domain.usecases

import com.py2pdf.domain.models.AnalysisResult
import com.py2pdf.domain.models.Diagnostic
import com.py2pdf.domain.models.Severity

class CodeAnalyzer {
    fun analyze(code: String): AnalysisResult {
        val diagnostics = mutableListOf<Diagnostic>()
        val restrictedModules = listOf("os", "subprocess", "sys", "shutil")
        val lines = code.lines()

        var hasBangla = false
        val banglaRegex = Regex("[\\u0980-\\u09FF]")

        lines.forEachIndexed { index, line ->
            val lineNum = index + 1
            
            if (banglaRegex.containsMatchIn(line)) {
                hasBangla = true
            }

            for (module in restrictedModules) {
                if (line.contains("import $module") || line.contains("from $module")) {
                    diagnostics.add(
                        Diagnostic(
                            line = lineNum,
                            message = "Security Warning: Module '$module' is restricted in local execution.",
                            severity = Severity.WARNING
                        )
                    )
                }
            }
        }

        if (hasBangla) {
            diagnostics.add(
                Diagnostic(
                    line = 1,
                    message = "Bangla Unicode detected. Ensure Noto Sans Bengali font is selected.",
                    severity = Severity.INFO
                )
            )
        }

        val hasErrors = diagnostics.any { it.severity == Severity.ERROR }
        return AnalysisResult(
            isValid = !hasErrors,
            diagnostics = diagnostics,
            hasBanglaText = hasBangla
        )
    }
}

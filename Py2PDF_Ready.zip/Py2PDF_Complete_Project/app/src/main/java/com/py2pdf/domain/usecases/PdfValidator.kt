package com.py2pdf.domain.usecases

import java.io.File

class PdfValidator {
    fun validatePdf(pdfFile: File): Boolean {
        if (!pdfFile.exists() || pdfFile.length() == 0L) return false
        return pdfFile.name.endsWith(".pdf", ignoreCase = true)
    }
}

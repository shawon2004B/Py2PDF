package com.py2pdf.engine.fonts

import android.content.Context
import android.graphics.Typeface
import com.py2pdf.domain.models.FontInfo
import java.io.File
import java.io.FileOutputStream

class FontManager(private val context: Context) {
    private val fontMap = mutableMapOf<String, Typeface>()

    fun getAvailableFonts(): List<FontInfo> {
        return listOf(
            FontInfo("Noto Sans Bengali", "noto_sans_bengali.ttf", isBanglaSupported = true),
            FontInfo("Roboto Regular", "roboto_regular.ttf", isBanglaSupported = false)
        )
    }

    fun loadFont(fontFileName: String): Typeface? {
        if (fontMap.containsKey(fontFileName)) return fontMap[fontFileName]

        return try {
            val typeface = Typeface.createFromAsset(context.assets, "fonts/$fontFileName")
            fontMap[fontFileName] = typeface
            typeface
        } catch (e: Exception) {
            null
        }
    }

    fun extractFontToCache(fontFileName: String): File? {
        return try {
            val file = File(context.cacheDir, fontFileName)
            if (!file.exists()) {
                context.assets.open("fonts/$fontFileName").use { input ->
                    FileOutputStream(file).use { output ->
                        input.copyTo(output)
                    }
                }
            }
            file
        } catch (e: Exception) {
            null
        }
    }
}

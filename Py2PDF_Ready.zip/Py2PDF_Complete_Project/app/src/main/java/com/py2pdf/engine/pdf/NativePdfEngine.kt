package com.py2pdf.engine.pdf

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.py2pdf.domain.interfaces.PdfGenerationEngine
import com.py2pdf.domain.models.PdfSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class NativePdfEngine(private val customTypeface: Typeface? = null) : PdfGenerationEngine {
    override suspend fun createPdf(text: String, outputPath: String, settings: PdfSettings): Boolean = withContext(Dispatchers.IO) {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        val paint = Paint().apply {
            textSize = 14f
            isAntiAlias = true
            customTypeface?.let { typeface = it }
        }

        var y = 50f
        text.lines().forEach { line ->
            canvas.drawText(line, 40f, y, paint)
            y += 20f
        }

        pdfDocument.finishPage(page)

        try {
            val file = File(outputPath)
            file.parentFile?.mkdirs()
            val outputStream = FileOutputStream(file)
            pdfDocument.writeTo(outputStream)
            pdfDocument.close()
            outputStream.close()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            pdfDocument.close()
            false
        }
    }
}

package com.py2pdf.engine.python

import com.chaquo.python.PyException
import com.chaquo.python.Python
import com.py2pdf.domain.interfaces.PythonExecutionEngine
import com.py2pdf.domain.models.ExecutionResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ChaquopyEngine : PythonExecutionEngine {
    override suspend fun executeScript(code: String, outputDir: String): ExecutionResult = withContext(Dispatchers.IO) {
        try {
            val py = Python.getInstance()
            val module = py.getModule("main")
            val result = module.callAttr("execute", code, outputDir)
            ExecutionResult(
                isSuccess = true,
                outputText = result.toString(),
                pdfPath = "$outputDir/generated_output.pdf"
            )
        } catch (e: PyException) {
            ExecutionResult(
                isSuccess = false,
                outputText = "",
                errorMessage = e.message ?: "Python Execution Error"
            )
        } catch (e: Exception) {
            ExecutionResult(
                isSuccess = false,
                outputText = "",
                errorMessage = e.localizedMessage ?: "Execution Failed"
            )
        }
    }
}

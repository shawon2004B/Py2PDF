package com.py2pdf.engine.python

import com.py2pdf.domain.interfaces.PythonExecutionEngine
import com.py2pdf.domain.models.ExecutionResult
import kotlinx.coroutines.delay

class MockPythonEngine : PythonExecutionEngine {
    override suspend fun executeScript(code: String, outputDir: String): ExecutionResult {
        delay(1000)
        return ExecutionResult(
            isSuccess = true,
            outputText = "Simulated Python Execution Completed Successfully.",
            pdfPath = "$outputDir/sample.pdf"
        )
    }
}

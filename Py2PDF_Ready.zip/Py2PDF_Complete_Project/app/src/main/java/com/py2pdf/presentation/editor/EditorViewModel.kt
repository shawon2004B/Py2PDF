package com.py2pdf.presentation.editor

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.py2pdf.domain.models.PythonProject
import com.py2pdf.domain.usecases.CodeAnalyzer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class EditorViewModel : ViewModel() {
    private val analyzer = CodeAnalyzer()

    private val _project = MutableStateFlow(
        PythonProject(
            code = "# Write Python script to generate document\nprint('Hello World!\\nস্বাগতম Py2PDF অ্যাপে')"
        )
    )
    val project: StateFlow<PythonProject> = _project

    fun updateCode(newCode: String) {
        _project.value = _project.value.copy(code = newCode)
    }

    fun runAnalysis() {
        viewModelScope.launch {
            val result = analyzer.analyze(_project.value.code)
        }
    }
}

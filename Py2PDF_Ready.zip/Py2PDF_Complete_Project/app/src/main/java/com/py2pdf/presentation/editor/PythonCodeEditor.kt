package com.py2pdf.presentation.editor

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PythonCodeEditor(
    code: String,
    onCodeChange: (String) -> Unit,
    onRunClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxSize().padding(16.dp)) {
        Text(
            text = "Py2PDF Code Editor",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        OutlinedTextField(
            value = code,
            onValueChange = onCodeChange,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            placeholder = { Text("Write Python code here...") },
            maxLines = Int.MAX_VALUE
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onRunClick,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Generate PDF")
        }
    }
}
